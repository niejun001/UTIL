package com.kyleduo.blogdemo.exchangefragment;

import android.os.Bundle;

/**
 * Created by kyle on 16/4/14.
 */
public class Holder3Fragment extends HolderFragment {

	@Override
	protected String getName() {
		return "holder_3";
	}
}
