package com.kyleduo.blogdemo.exchangefragment;

/**
 * Created by kyle on 16/4/14.
 */
public class ExchangedFragment extends HolderFragment {

	@Override
	protected String getName() {
		return "holder_EXCHANGED";
	}
}
