//
//  ExtensionDelegate.h
//  TestWatchOS Extension
//
//  Created by kyle on 16/4/18.
//  Copyright © 2016年 kyleduo. All rights reserved.
//

#import <WatchKit/WatchKit.h>

@interface ExtensionDelegate : NSObject <WKExtensionDelegate>

@end
