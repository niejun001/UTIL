//
//  TestJsonModel.h
//  PCHImportProblem
//
//  Created by kyle on 16/4/18.
//  Copyright © 2016年 kyleduo. All rights reserved.
//

#import "JSONModel.h"

@interface TestJsonModel : JSONModel

@property (nonatomic, copy) NSString *name;

@end
