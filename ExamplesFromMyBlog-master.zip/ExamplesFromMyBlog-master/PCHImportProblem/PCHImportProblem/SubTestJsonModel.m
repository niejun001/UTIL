//
//  SubTestJsonModel.m
//  PCHImportProblem
//
//  Created by kyle on 16/4/18.
//  Copyright © 2016年 kyleduo. All rights reserved.
//

#import "SubTestJsonModel.h"

@implementation SubTestJsonModel

@end
