//
//  SubTestJsonModel.h
//  PCHImportProblem
//
//  Created by kyle on 16/4/18.
//  Copyright © 2016年 kyleduo. All rights reserved.
//

#import "TestJsonModel.h"

@interface SubTestJsonModel : TestJsonModel

@end
