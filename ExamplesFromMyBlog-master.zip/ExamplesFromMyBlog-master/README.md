# ExamplesFromMyBlog

This Repository contains source code of some demos in my blog. -->  [https://kyleduo.com](https://kyleduo.com)



### [Digging] Android Translucent Status Bar

How to implement perfect translucent bar in >= 4.4 and why.

![cover](https://static.kyleduo.com/blog/image/digging-translucentstatusbar/cover.png)





### ExchangeFragment

Exchange fragment in FragmentTabHost.

[Link](https://blog.kyleduo.com/2016/04/14/exchange-fragment-in-fragmenttabhost/)

Preview:

![Preview](./preview/ExchangeFragment.gif)

